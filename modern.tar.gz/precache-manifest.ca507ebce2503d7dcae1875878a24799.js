self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "18c1a38b453e539c0a55",
    "url": "css/app.084e4317.css"
  },
  {
    "revision": "3a9e5bb8f7f27c25cb92",
    "url": "css/chunk-vendors.d21c70ba.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "eb3a5b77d2ef6a819e1818fde7ead860",
    "url": "index.html"
  },
  {
    "revision": "cd918a04c2a1d73bbd624505d5271199",
    "url": "js/0-legacy.24b17fed.worker.js"
  },
  {
    "revision": "18c1a38b453e539c0a55",
    "url": "js/app-legacy.bd05f593.js"
  },
  {
    "revision": "3a9e5bb8f7f27c25cb92",
    "url": "js/chunk-vendors-legacy.d51496b3.js"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);