namespace ZonyLrcTools.Cli.Infrastructure.Lyric.NetEase.JsonModel
{
    public static class SongSearchResponseStatusCode
    {
        public const int Success = 200;
    }
}