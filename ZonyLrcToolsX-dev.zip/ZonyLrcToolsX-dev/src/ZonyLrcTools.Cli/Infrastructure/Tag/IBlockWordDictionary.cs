﻿namespace ZonyLrcTools.Cli.Infrastructure.Tag
{
    public interface IBlockWordDictionary
    {
        string GetValue(string key);
    }
}