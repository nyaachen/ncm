English | [简体中文](./zh_CN.md)

## Overview

ZonyLrcToolX 2.0 is a cross-platform lyric downlaod tool based on CEF.  

🚧 The current version is under development.  
🚧 If you want to see the working code, please switch to the 1.0 branch.

## Usage

## Donation

## Roadmap

- [ ] Supports cross-platform CLI tools.
- [ ] Web GUI based site (local).
- [ ] Support plug-in system (Lua Engine).