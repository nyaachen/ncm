self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f964984d06f6c9354b2f",
    "url": "css/app.084e4317.css"
  },
  {
    "revision": "3a9e5bb8f7f27c25cb92",
    "url": "css/chunk-vendors.d21c70ba.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "5cdb9f31bfb3d0eb3d150013a4ab6fb1",
    "url": "index.html"
  },
  {
    "revision": "2d12777f2703612307ff4a12f1b21899",
    "url": "ixarea-stats.js"
  },
  {
    "revision": "cd918a04c2a1d73bbd624505d5271199",
    "url": "js/0.24b17fed.worker.js"
  },
  {
    "revision": "f964984d06f6c9354b2f",
    "url": "js/app.a3195ea6.js"
  },
  {
    "revision": "3a9e5bb8f7f27c25cb92",
    "url": "js/chunk-vendors.d51496b3.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);