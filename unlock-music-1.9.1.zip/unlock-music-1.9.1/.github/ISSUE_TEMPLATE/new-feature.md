---
name: 新功能
about: 对于程序新的想法或建议
title: ''
labels: enhancement
assignees: ''

---

- 请按照此模板填写，否则可能立即被关闭

**背景和说明**

简要说明产生此想法的背景和此想法的具体内容


**实现途径**

- 如果没有设计方案，请简要描述实现思路
- 如果你没有任何的实现思路，请通过[Discussions](https://github.com/ix64/unlock-music/discussions)或者Telegram进行讨论


**附加信息**

更多你想要表达的内容

