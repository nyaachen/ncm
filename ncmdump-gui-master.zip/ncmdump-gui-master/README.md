# ncmdump-gui

tool base on [ncmdump](https://github.com/anonymous5l/ncmdump)

release windows version on [release](https://github.com/anonymous5l/ncmdump-gui/releases/tag/fully)

ncmdump windows gui dev by vs2017

use simple open DesktopTool.sln and build

nuget dependent `taglib_sharp`
