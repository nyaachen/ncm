import {expose} from "threads/worker";
import {CommonDecrypt} from "@/decrypt/common";

expose(CommonDecrypt)
