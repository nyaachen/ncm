self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "39baf5ab61b3643d7bc5",
    "url": "css/app.084e4317.css"
  },
  {
    "revision": "151e7a6b83ba75e22c76",
    "url": "css/chunk-vendors.d21c70ba.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "4119faf8d569ec32df6cb8579b4277d4",
    "url": "index.html"
  },
  {
    "revision": "2d12777f2703612307ff4a12f1b21899",
    "url": "ixarea-stats.js"
  },
  {
    "revision": "d3a4913df2be01a26e0c95fe09449855",
    "url": "js/0.1a49785e.worker.js"
  },
  {
    "revision": "39baf5ab61b3643d7bc5",
    "url": "js/app.782ae3c8.js"
  },
  {
    "revision": "151e7a6b83ba75e22c76",
    "url": "js/chunk-vendors.ed26a81d.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);